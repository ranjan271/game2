var canvas,ychicken;
var ychickenImg, ychickenImg2;
var arrow,arrowImg;

function preload()
{
    ychickenImg = loadImage('chik1.png')
    ychickenImg2 = loadImage('chik2.png')
    arrowImg = loadImage('arrow.png')
}
 
function setup()
{
    canvas=createCanvas(800,600);
}

function draw()
{
    background(0);
    moveArrow()
    moveChicken()

    if(keyDown(RIGHT_ARROW))
    {
        arrow.velocityX=4;
        arrow.lifetime=20;
        arrow.velocityY=0;
    }
    if(keyDown(LEFT_ARROW))
    {
        arrow.velocityX=-4;
        arrow.lifetime=20;
        arrow.velocityY=0;
    }
    if(keyDown(UP_ARROW))
    {
        arrow.velocityX=0;
        arrow.velocityY=-5;
        arrow.lifetime=70;
    }

    


    drawSprites();
}


function moveChicken()
{
    if(frameCount%60==0){
        ychicken = createSprite(800,100,60,40);
        var y = Math.round(random(100,400))
        console.log(y)
        ychicken.y=y
        ychicken.velocityX=-5;
        ychicken.addImage('yellowchicken',ychickenImg);
        ychicken.scale=0.5;
        ychicken.lifetime=250;
        

    }
}

function moveArrow()
{
    if(frameCount%120==0){
        arrow=createSprite(350,600,60,40)
        var y = Math.round(random(650,600))
        console.log(y)
        arrow.velocityY=-5;
        arrow.y=y
        arrow.addImage('arrows',arrowImg);
        arrow.scale=0.4;
        arrow.lifetime=150;
    }

    
}
if(arrow.isTouching(ychicken))
{
    arrow.velocityX=0;
    arrow.velocityY=0;
    ychicken.velocityX=0;
    ychicken.velocityY=0;
    fill("lime");
    textSize(25);
    text("shoot me shoot me again...." ,250,250)
}











